System.register([],(function(e){"use strict";return{execute:function(){function t(e){return window.matchMedia&&window.matchMedia(`(prefers-color-scheme: ${e})`).matches}e("g",(function(){if(t("dark"))return"dark";if(t("light"))return"light";return}))}}}));
//# sourceMappingURL=chunk-color-modes-9df733f9.js.map
